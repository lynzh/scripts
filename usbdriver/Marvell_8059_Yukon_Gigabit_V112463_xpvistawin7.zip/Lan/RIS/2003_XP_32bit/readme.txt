�Copyright 2008 Marvell�.
All rights reserved.

================================================================================


Readme File for Marvell Miniport driver supporting Windows XP/Server 2003 
(32 bit) for use on a Windows 2000 RIS Server


This file contains:
 
1   Overview
2   Required Files
3   Adding a Driver with RIS Installation Support
    3.1  Adding the Driver into the RIS Image  
    3.2  Preparing the RIS Image for Driver Installation
    3.3  Stopping and Restarting the Remote Installation Service (BINLSVC)
  
================================================================================


1   Overview
============

This readme file describes how to add the Marvell Windows driver to a 
Windows 2000 RIS server installation image.

For further information, see the Microsoft knowledge base article 315279
"How to Add Third-Party OEM Network Adapters to RIS Installations".


2   Required Files  
==================

yk51x86_vX.X.X_inbuild.zip, containing the following files:

  - YK51X86.sys: Miniport driver, NDIS5.1
  - YK51X86.inf: INF file created for use on a Windows 2000 RIS Server
  - readme.txt : Readme file

NOTE: The INF file included in the default Marvell Windows driver package does 
      not provide RIS installation support. Therefore, the RIS server cannot 
      find a valid driver for the RIS client's network controller.


3   Adding a Driver with RIS Installation Support
=================================================

3.1 Adding the Driver to the RIS Image  
--------------------------------------

To add the driver that supports RIS installation:

1. Copy the driver files into the "i386" folder of the RIS installation image. 
   The default path for the image is 
   
   \\RIS Server\RemoteInstall\Setup\language\Images\RIS Image Name\i386\

   Example: \\RIS2000_Server\RemoteInstall\Setup\English\Images\WXP_SP1\i386\

2. Delete all *.pnf files from the "i386" folder.

3. On the same level where the "i386" folder is located, create the following 
   subfolder structure: \$oem$\$1\Drivers\Marvell

4. In the [Unattended] section of the ristndrd.sif files, add or change the 
   following lines:

   DriverSigningPolicy = Ignore
   OemPreinstall = yes
   OemPnpDriversPath = Drivers\Marvell

   There are two files with this name, which are located in the directories 
   "i386" and "i386\templates". Make sure that each entry is included once only
   and that you adapt both files.


3.2 Preparing the RIS Image for Driver Installation
---------------------------------------------------

To ensure that the added driver will be installed in the Windows XP partition of
the RIS client:

1. In the "i386" folder of your RIS image, create the following folder:
   \Mirror1\UserData\Drivers\Marvell

2. Copy the following files into this folder:
   
   YK51X86.sys
   YK51X86.inf


3.3 Stopping and Restarting the Remote Installation Service (BINLSVC)
---------------------------------------------------------------------

Stopping and restarting the remote installation service is required, 
because the Boot Information Negotiation Layer (BINL) needs to read the 
new network controller related INF file and create a PNF file in the image.

To stop and restart the remote installation service:

1. Open a command shell (cmd).

2. Perform the following commands:

   net stop binlsvc
   net start binlsvc



*** End of Readme File ***